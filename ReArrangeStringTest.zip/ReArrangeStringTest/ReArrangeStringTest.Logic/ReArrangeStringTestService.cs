﻿using ReArrangeStringTest.Helper;
namespace ReArrangeStringTest.Logic;

public class ReArrangeStringTestService : IReArrangeStringTest
{
    public async Task<string> GetArrangedString(string inputString, int interval)
    {
        var resultArray =  StringHelper.GetStringWrapped(inputString, interval).Take(inputString.Length).ToArray();

        return  string.Join("", resultArray);
    }

  
}