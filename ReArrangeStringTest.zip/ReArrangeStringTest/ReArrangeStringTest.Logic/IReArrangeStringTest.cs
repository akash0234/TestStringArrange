﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReArrangeStringTest.Logic
{
    public interface IReArrangeStringTest
    {
        public Task<string> GetArrangedString(string str, int interval);

    }
}
