﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ReArrangeStringTest.Logic;

namespace ReArrangeStringTestApi.Controllers
{
    

    [Route("[controller]")]
    [ApiController]
    public class StringArrangeController : ControllerBase
    {
        private readonly IReArrangeStringTest _reArrangeStringTest;

        public StringArrangeController(IReArrangeStringTest reArrangeStringTest)
        {
            _reArrangeStringTest = reArrangeStringTest;
                
        }
        [HttpGet("get-arranged-string/{myString}/{interval}")]
        public async Task<IActionResult> ReArrangeString(string myString, int interval)
        {
            string arrangedstring = await _reArrangeStringTest.GetArrangedString(myString, interval);

            return Ok(arrangedstring);
        }

    }
}
