﻿namespace ReArrangeStringTest.Helper
{
    public class StringHelper
    {
        public  static IEnumerable<string> GetStringWrapped(string myString, int position)
        {
            string[] strings = myString.ToCharArray().Select(c => c.ToString()).ToArray();


            int current = position - 1;
            while (true)
            {
                yield return strings[current];
                current += position;
                current %= strings.Length;
            }
        }
    }
}