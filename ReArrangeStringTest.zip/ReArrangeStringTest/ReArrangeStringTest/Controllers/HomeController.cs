﻿using Microsoft.AspNetCore.Mvc;
using ReArrangeStringTest.Models;
using System.Diagnostics;

namespace ReArrangeStringTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly string _myApi;
        private readonly IHttpClientFactory _clientFactory;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration, IHttpClientFactory clientFactory)
        {
            _myApi = configuration["ApiUrl"];
            _logger = logger;
            _clientFactory = clientFactory;

        }

        public IActionResult Index()
        {

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> GenerateString(string InputString , int Interval)
        {
            if (InputString.Length != 11 || InputString == null)
            {
                TempData["Error"] = "Please Enter 11 Unique Chars";

            }
            else
            {
                //Get Order
                var client = _clientFactory.CreateClient();
                var requestGetOrder = new HttpRequestMessage(HttpMethod.Get, _myApi + "/StringArrange/get-arranged-string/" + InputString + "/" + Interval);
                var responseGetOrder = await client.SendAsync(requestGetOrder);

                responseGetOrder.EnsureSuccessStatusCode();
                var orderObj = await responseGetOrder.Content.ReadAsStringAsync();
                TempData["Success"] = orderObj;
            }
            return Redirect("~/");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}